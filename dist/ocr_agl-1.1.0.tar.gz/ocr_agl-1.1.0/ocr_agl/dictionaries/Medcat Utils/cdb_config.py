config = Config()
config.general['spacy_model'] = 'en_core_web_md'
maker = CDBMaker(config)